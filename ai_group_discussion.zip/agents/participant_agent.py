def simulate_group_discussion(user_argument):
    personas = [
        "Optimist Economist",
        "Critical Thinker",
        "Neutral Analyst",
        "Devil's Advocate"
    ]

    simulated_transcript = f"You: {user_argument}\n\n"
    for persona in personas:
        simulated_transcript += f"{persona}: " + generate_response(persona, user_argument) + "\n\n"

    return simulated_transcript

def generate_response(role, context):
    return f"As a {role}, I believe {context} needs to consider..."